
		room=a;